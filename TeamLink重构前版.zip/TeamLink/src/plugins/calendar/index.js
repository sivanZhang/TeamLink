/**
 * vue-calendar-component
 */
import Calendar from './calendar.vue';
export default Calendar;
