export default {
    token: '',
    user_name: '',
    portrait: '',
    search_text: '',
    url: '',
    agents: [null],
    BASE_URL: '',
}